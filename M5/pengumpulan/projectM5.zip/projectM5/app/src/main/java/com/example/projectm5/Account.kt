package com.example.projectm5

data class Account (
    var name: String,
    var balance: Int
){
}