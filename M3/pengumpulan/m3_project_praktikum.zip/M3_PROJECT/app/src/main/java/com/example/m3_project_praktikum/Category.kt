package com.example.m3_project_praktikum

class Category (
    var photo: Int,
    var title: String
)