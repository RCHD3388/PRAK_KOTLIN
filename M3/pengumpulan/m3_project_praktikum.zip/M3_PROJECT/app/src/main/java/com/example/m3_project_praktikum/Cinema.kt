package com.example.m3_project_praktikum

class Cinema (
    var title: String,
    var address: String,
    var telp: String,
    var distance: String,
    var type: ArrayList<String>,
)