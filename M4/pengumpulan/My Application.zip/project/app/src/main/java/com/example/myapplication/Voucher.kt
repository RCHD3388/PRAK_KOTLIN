package com.example.myapplication

data class Voucher (
    val tipe: String,
    val potongan: Int,
    val minimum: Int
)